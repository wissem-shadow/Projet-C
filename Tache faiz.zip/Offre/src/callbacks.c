#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "offre.h"
#include <stdio.h>

enum 
{
	ID,
	DATE_DE_DEPART,
	DATE_ARRIVEE,
	NOM_DE_PAYS,
	PRIX,
	COLUMNS
};

void
on_buttonajouter_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *gerer_offre;
GtkWidget *Ajouter;

gerer_offre=lookup_widget(objet,"gerer_offre");

gtk_widget_destroy(gerer_offre);
Ajouter=create_Ajouter();
gtk_widget_show(Ajouter);

}


void
on_buttonAjouter2_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
offre o;
GtkWidget *output1 = lookup_widget(objet,"labelMsg3");
GtkWidget *entryDepart, *entryArrivee, *entryPays, *entryPrix;
GtkWidget *Ajouter;

Ajouter=lookup_widget(objet,"Ajouter");
entryDepart=lookup_widget(objet,"entryDepart");
entryArrivee=lookup_widget(objet,"entryArrivee");
entryPays=lookup_widget(objet,"entryPays");
entryPrix=lookup_widget(objet,"entryPrix");


strcpy(o.date_de_depart,gtk_entry_get_text(GTK_ENTRY(entryDepart)));
strcpy(o.date_arriver,gtk_entry_get_text(GTK_ENTRY(entryArrivee)));
strcpy(o.nom_de_pays,gtk_entry_get_text(GTK_ENTRY(entryPays)));
strcpy(o.prix,gtk_entry_get_text(GTK_ENTRY(entryPrix)));

ajouter_offre(o);
gtk_label_set_text(GTK_LABEL(output1)," Offre ajouté");
}



void
on_buttonRetour1_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *gerer_offre;
GtkWidget *Ajouter;

Ajouter=lookup_widget(objet,"Ajouter");

gtk_widget_destroy(Ajouter);
gerer_offre=create_gerer_offre();
gtk_widget_show(gerer_offre);

}


void
on_buttonmodifier_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *gerer_offre;
GtkWidget *Modifier;
GtkWidget *treeviewModifier;


gerer_offre=lookup_widget(objet,"gerer_offre");

gtk_widget_destroy(gerer_offre);
Modifier=lookup_widget(objet,"Modifier");
Modifier=create_Modifier();
gtk_widget_show(Modifier);

treeviewModifier=lookup_widget(Modifier,"treeviewModifier");

afficher_presonne(treeviewModifier);
}


void
on_buttonRechercher_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{

char rechercher1 [50] ;

GtkWidget *entryRechercher1;
GtkWidget *Modifier;
GtkWidget *treeviewModifier;
GtkCellRenderer *renderer; 
	GtkTreeModel *model;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store; 
	int id;
	char date_de_depart[20];
	char date_arriver[20];
	char nom_de_pays[30];
	char prix[20];
	store=NULL;

FILE* f=fopen("offre.txt","a+");
FILE* f1=fopen("recherche1.txt","a+");
Modifier=lookup_widget(objet,"Modifier");
entryRechercher1=lookup_widget(objet,"entryRechercher1");

strcpy(rechercher1,gtk_entry_get_text(GTK_ENTRY(entryRechercher1)));
if(f!=NULL)
 {
  while(fscanf(f,"%d %s %s %s %s\n",&id , date_de_depart ,date_arriver , nom_de_pays , prix)!=EOF)
  {
 if ((strcmp (rechercher1,nom_de_pays) == 0))
   {
  if(f1!=NULL)
        {
             fprintf(f1,"%d %s %s %s %s\n"  , id , date_de_depart , date_arriver , nom_de_pays , prix);
        }
}
 }
 }
  fclose(f);
  fclose(f1);
treeviewModifier=lookup_widget(Modifier,"treeviewModifier"); 
	store=gtk_tree_view_get_model(treeviewModifier);
	if(store!=NULL)
	{
renderer=gtk_cell_renderer_text_new();
	      	column=gtk_tree_view_column_new_with_attributes("id", 			renderer, "text",ID,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewModifier),column);
		renderer=gtk_cell_renderer_text_new();
	      	column=gtk_tree_view_column_new_with_attributes("date_de_depart", 			renderer, "text",DATE_DE_DEPART,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewModifier),column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("date_arriver", 			renderer, "text",DATE_ARRIVEE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewModifier),column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("nom_de_pays", 			renderer, "text",NOM_DE_PAYS,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewModifier),column);
renderer=gtk_cell_renderer_text_new();
	      	column=gtk_tree_view_column_new_with_attributes("prix", 			renderer, "text",PRIX,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewModifier),column);
		
		store=gtk_list_store_new 				( COLUMNS,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
		f1=fopen("recherche1.txt","r");
		if(f1==NULL)
		{
			return;
		}
		else{
			f1=fopen("recherche1.txt","a+");
		while(fscanf(f1,"%d %s %s %s %s\n",&id , date_de_depart ,date_arriver , nom_de_pays , prix)!=EOF)
		{
		gtk_list_store_append (store, &iter); 
		 gtk_list_store_set(store, &iter, ID,id , DATE_DE_DEPART,date_de_depart ,DATE_ARRIVEE,date_arriver ,NOM_DE_PAYS, 				nom_de_pays ,PRIX,prix ,-1 ); 
		}
		fclose(f1); 
		}
							gtk_tree_view_set_model(GTK_TREE_VIEW(treeviewModifier),GTK_TREE_MODEL(store));
		g_object_unref(store);
		}
remove("recherche1.txt");
}


void
on_buttonModifier2_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{  
offre o;
int id;
int test;
GtkWidget *entryModifier1, *entryModifier2, *entryModifier3, *entryModifier4, *entryModifier5;
char id1 [50] ;
GtkWidget *Modifier;
GtkWidget *treeviewModifier;
GtkCellRenderer *renderer;
GtkWidget *output1 = lookup_widget(objet,"labelMsg"); 
	GtkTreeModel *model;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char date_de_depart[20];
	char date_arriver[20];
	char nom_de_pays[30];
	char prix[20];
	store=NULL;



Modifier=lookup_widget(objet,"Modifier");
entryModifier1=lookup_widget(objet,"entryModifier1");
entryModifier2=lookup_widget(objet,"entryModifier2");
entryModifier3=lookup_widget(objet,"entryModifier3");
entryModifier4=lookup_widget(objet,"entryModifier4");
entryModifier5=lookup_widget(objet,"entryModifier5");

id= atoi(gtk_entry_get_text(GTK_ENTRY(entryModifier1)));
strcpy(o.date_de_depart,gtk_entry_get_text(GTK_ENTRY(entryModifier2)));
strcpy(o.date_arriver,gtk_entry_get_text(GTK_ENTRY(entryModifier3)));
strcpy(o.nom_de_pays,gtk_entry_get_text(GTK_ENTRY(entryModifier4)));
strcpy(o.prix,gtk_entry_get_text(GTK_ENTRY(entryModifier5)));
test=verif_offre(id);
if (test == 1 ){
    modifier_offre(o , id);
    gtk_label_set_text(GTK_LABEL(output1)," Offre modifié");
  }else{
    gtk_label_set_text(GTK_LABEL(output1),"Error: ID Offre non exist!");
  }



FILE* f=fopen("offre.txt","a+");

treeviewModifier=lookup_widget(Modifier,"treeviewModifier"); 

	store=gtk_tree_view_get_model(treeviewModifier);
	column=NULL;
	if(store!=NULL)
	{
renderer=gtk_cell_renderer_text_new();
	      	column=gtk_tree_view_column_new_with_attributes("id", 			renderer, "text",ID,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewModifier),column);
		renderer=gtk_cell_renderer_text_new();
	      	column=gtk_tree_view_column_new_with_attributes("date_de_depart", 			renderer, "text",DATE_DE_DEPART,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewModifier),column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("date_arriver", 			renderer, "text",DATE_ARRIVEE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewModifier),column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("nom_de_pays", 			renderer, "text",NOM_DE_PAYS,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewModifier),column);
renderer=gtk_cell_renderer_text_new();
	      	column=gtk_tree_view_column_new_with_attributes("prix", 			renderer, "text",PRIX,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewModifier),column);
		
		store=gtk_list_store_new 				( COLUMNS,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
		f=fopen("offre.txt","r");
		if(f==NULL)
		{
			return;
		}
		else{
			f=fopen("offre.txt","a+");
		while(fscanf(f,"%d %s %s %s %s\n", &id , date_de_depart ,date_arriver , nom_de_pays , prix)!=EOF)
		{
		gtk_list_store_append (store, &iter); 
		 gtk_list_store_set(store, &iter, ID,id,  DATE_DE_DEPART,date_de_depart ,DATE_ARRIVEE,date_arriver ,NOM_DE_PAYS, 				nom_de_pays, PRIX,prix ,-1 ); 
		}
		fclose(f); 
		}
							gtk_tree_view_set_model(GTK_TREE_VIEW(treeviewModifier),GTK_TREE_MODEL(store));
		g_object_unref(store);
		}
}



void
on_buttonRetour2_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *gerer_offre;
GtkWidget *Modifier;

Modifier=lookup_widget(objet,"Modifier");

gtk_widget_destroy(Modifier);
gerer_offre=create_gerer_offre();
gtk_widget_show(gerer_offre);
}


void
on_buttonAfficher_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *gerer_offre;
GtkWidget *Afficher;
GtkWidget *treeviewAfficher;


gerer_offre=lookup_widget(objet,"gerer_offre");

gtk_widget_destroy(gerer_offre);
Afficher=lookup_widget(objet,"Afficher");
Afficher=create_Afficher();
gtk_widget_show(Afficher);

treeviewAfficher=lookup_widget(Afficher,"treeviewAfficher");

afficher_presonne(treeviewAfficher);

}


void
on_buttonRetour3_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *gerer_offre;
GtkWidget *Afficher;

Afficher=lookup_widget(objet,"Afficher");

gtk_widget_destroy(Afficher);
gerer_offre=create_gerer_offre();
gtk_widget_show(gerer_offre);
}

void
on_buttonRechercher2_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{

char rechercher2 [50] ;

GtkWidget *entryRechercher2;
GtkWidget *Supprimer;
GtkWidget *treeviewSupprimer;
GtkCellRenderer *renderer; 
	GtkTreeModel *model;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	int id; 
	char date_de_depart[20];
	char date_arriver[20];
	char nom_de_pays[30];
	char prix[20];
	store=NULL;

FILE* f=fopen("offre.txt","a+");
FILE* f1=fopen("recherche2.txt","a+");
Supprimer=lookup_widget(objet,"Supprimer");
entryRechercher2=lookup_widget(objet,"entryRechercher2");

strcpy(rechercher2,gtk_entry_get_text(GTK_ENTRY(entryRechercher2)));
if(f!=NULL)
 {
  while(fscanf(f,"%d %s %s %s %S\n", &id , date_de_depart ,date_arriver , nom_de_pays ,prix)!=EOF)
  {
 if ((strcmp (rechercher2,nom_de_pays) == 0))
   {
  if(f1!=NULL)
        {
             fprintf(f1,"%d %s %s %s %s\n" , id , date_de_depart , date_arriver , nom_de_pays , prix);
        }
}
 }
 }
  fclose(f);
  fclose(f1);
treeviewSupprimer=lookup_widget(Supprimer,"treeviewSupprimer"); 

	store=gtk_tree_view_get_model(treeviewSupprimer);
	column=NULL;
	if(store!=NULL)
	{
renderer=gtk_cell_renderer_text_new();
	      	column=gtk_tree_view_column_new_with_attributes("id", 			renderer, "text",ID,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewSupprimer),column);
		renderer=gtk_cell_renderer_text_new();
	      	column=gtk_tree_view_column_new_with_attributes("date_de_depart", 			renderer, "text",DATE_DE_DEPART,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewSupprimer),column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("date_arriver", 			renderer, "text",DATE_ARRIVEE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewSupprimer),column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("nom_de_pays", 			renderer, "text",NOM_DE_PAYS,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewSupprimer),column);
renderer=gtk_cell_renderer_text_new();
	      	column=gtk_tree_view_column_new_with_attributes("prix", 			renderer, "text",PRIX,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewSupprimer),column);
		
		store=gtk_list_store_new 				( COLUMNS,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
		f1=fopen("recherche2.txt","r");
		if(f1==NULL)
		{
			return;
		}
		else{
			f1=fopen("recherche2.txt","a+");
		while(fscanf(f1,"%d %s %s %s %s\n", &id , date_de_depart ,date_arriver , nom_de_pays , prix)!=EOF)
		{
		gtk_list_store_append (store, &iter); 
		 gtk_list_store_set(store, &iter, ID,id,  DATE_DE_DEPART,date_de_depart ,DATE_ARRIVEE,date_arriver ,NOM_DE_PAYS, 				nom_de_pays, PRIX,prix ,-1 ); 
		}
		fclose(f1); 
		}
							gtk_tree_view_set_model(GTK_TREE_VIEW(treeviewSupprimer),GTK_TREE_MODEL(store));
		g_object_unref(store);
		}
remove("recherche2.txt");
}


void
on_buttonRetour4_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *gerer_offre;
GtkWidget *Supprimer;

Supprimer=lookup_widget(objet,"Supprimer");

gtk_widget_destroy(Supprimer);
gerer_offre=create_gerer_offre();
gtk_widget_show(gerer_offre);
}


void
on_buttonSupprimer2_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{char id1 [50] ;
int test;
int id;
GtkWidget *output1 = lookup_widget(objet,"labelMsg2");
GtkWidget *entrySupprimer;
GtkWidget *Supprimer;
GtkWidget *treeviewSupprimer;
GtkCellRenderer *renderer; 
	GtkTreeModel *model;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char date_de_depart[20];
	char date_arriver[20];
	char nom_de_pays[30];
	char prix[20];
	store=NULL;


Supprimer=lookup_widget(objet,"Supprimer");
entrySupprimer=lookup_widget(objet,"entrySupprimer");

strcpy(id1,gtk_entry_get_text(GTK_ENTRY(entrySupprimer)));
id= atoi(id1);

test=verif_offre(id);
if (test == 1 ){
    supprimer_offre(id);
    gtk_label_set_text(GTK_LABEL(output1)," Offre Supprimé");
  }else{
    gtk_label_set_text(GTK_LABEL(output1),"Error: ID Offre non exist !");
  }





FILE* f=fopen("offre.txt","a+");

treeviewSupprimer=lookup_widget(Supprimer,"treeviewSupprimer"); 

	store=gtk_tree_view_get_model(treeviewSupprimer);
	column=NULL;
	if(store!=NULL)
	{
renderer=gtk_cell_renderer_text_new();
	      	column=gtk_tree_view_column_new_with_attributes("id", 			renderer, "text",ID,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewSupprimer),column);
		renderer=gtk_cell_renderer_text_new();
	      	column=gtk_tree_view_column_new_with_attributes("date_de_depart", 			renderer, "text",DATE_DE_DEPART,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewSupprimer),column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("date_arriver", 			renderer, "text",DATE_ARRIVEE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewSupprimer),column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("nom_de_pays", 			renderer, "text",NOM_DE_PAYS,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewSupprimer),column);
renderer=gtk_cell_renderer_text_new();
	      	column=gtk_tree_view_column_new_with_attributes("prix", 			renderer, "text",PRIX,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewSupprimer),column);
		
		store=gtk_list_store_new 				( COLUMNS,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
		f=fopen("offre.txt","r");
		if(f==NULL)
		{
			return;
		}
		else{
			f=fopen("offre.txt","a+");
		while(fscanf(f,"%d %s %s %s %s\n", &id , date_de_depart ,date_arriver , nom_de_pays , prix)!=EOF)
		{
		gtk_list_store_append (store, &iter); 
		 gtk_list_store_set(store, &iter, ID,id,  DATE_DE_DEPART,date_de_depart ,DATE_ARRIVEE,date_arriver ,NOM_DE_PAYS, 				nom_de_pays, PRIX,prix ,-1 ); 
		}
		fclose(f); 
		}
							gtk_tree_view_set_model(GTK_TREE_VIEW(treeviewSupprimer),GTK_TREE_MODEL(store));
		g_object_unref(store);
		}

}


void
on_buttonSupprimer_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *gerer_offre;
GtkWidget *Supprimer;
GtkWidget *treeviewSupprimer;


gerer_offre=lookup_widget(objet,"gerer_offre");

gtk_widget_destroy(gerer_offre);
Supprimer=lookup_widget(objet,"Supprimer");
Supprimer=create_Supprimer();
gtk_widget_show(Supprimer);

treeviewSupprimer=lookup_widget(Supprimer,"treeviewSupprimer");

afficher_presonne(treeviewSupprimer);
}

