#include <gtk/gtk.h>

typedef struct
{
int id;
char date_de_depart[20];
char date_arriver[20];
char nom_de_pays[30];
char prix[20];

}offre;

void ajouter_offre(offre o);
void afficher_presonne(GtkWidget *liste);
void supprimer_offre(int id);
void modifier_offre(offre d ,int id);
