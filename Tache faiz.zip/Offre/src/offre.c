#include <stdio.h>
#include <string.h>
#include "offre.h"
#include <gtk/gtk.h>
#include <stdlib.h>

enum 
{
	ID,
	DATE_DE_DEPART,
	DATE_ARRIVEE,
	NOM_DE_PAYS,
	PRIX,
	COLUMNS
};

void ajouter_offre(offre o)
{
offre d;
int s=0;
	FILE *f;
	f=fopen("offre.txt","a+");
	if(f!=NULL)
	{ while(fscanf(f,"%d %s %s %s %s\n",&d.id, d.date_de_depart ,d.date_arriver , d.nom_de_pays , d.prix)!=EOF)
{s++;}
	s++;
	o.id=s;
	 fprintf(f,"%d %s %s %s %s\n" , o.id , o.date_de_depart, o.date_arriver ,o.nom_de_pays, o.prix);
	fclose(f);
}
}
void afficher_presonne(GtkWidget *liste)
{
	GtkCellRenderer *renderer; 
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	int id; 
	char date_de_depart[20];
	char date_arriver[20];
	char nom_de_pays[30];
	char prix[20];
	store=NULL;
	FILE *f; 
	store=gtk_tree_view_get_model(liste);
	if(store==NULL)
	{
	renderer=gtk_cell_renderer_text_new();
	      	column=gtk_tree_view_column_new_with_attributes("id", 			renderer, "text",ID,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
	renderer=gtk_cell_renderer_text_new();
	      column=gtk_tree_view_column_new_with_attributes("date_de_depart", 			renderer, "text",DATE_DE_DEPART,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
	renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("date_arriver", 			renderer, "text",DATE_ARRIVEE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
	renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("nom_de_pays", 			renderer, "text",NOM_DE_PAYS,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
	renderer=gtk_cell_renderer_text_new();
	      	column=gtk_tree_view_column_new_with_attributes("prix", 			renderer, "text",PRIX,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		store=gtk_list_store_new 				( COLUMNS,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
		f=fopen("offre.txt","r");
		if(f==NULL)
		{
			return;
		}
		else{
			f=fopen("offre.txt","a+");
		while(fscanf(f,"%d %s %s %s %s\n",&id, date_de_depart ,date_arriver , nom_de_pays , prix)!=EOF)
		{
		gtk_list_store_append (store, &iter); 
		 gtk_list_store_set(store, &iter, ID,id, DATE_DE_DEPART,date_de_depart ,DATE_ARRIVEE,date_arriver ,NOM_DE_PAYS, 				nom_de_pays,PRIX ,prix,-1 ); 
		}
		fclose(f); 
		}
							gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
		g_object_unref(store);
		}
		}


void supprimer_offre(int id)
{
	int s=0;
	offre o;
	FILE*f;
  FILE*f1;
  f=fopen("offre.txt","r");
	f1=fopen("recherche.txt","w");

  while(fscanf(f,"%d %s %s %s %s\n",&o.id, o.date_de_depart ,o.date_arriver , o.nom_de_pays , o.prix)!=EOF)
  { s++;
    		if(id != o.id)
    		{ 
		o.id=s;
		fprintf(f1,"%d %s %s %s %s\n",o.id,
o.date_de_depart ,o.date_arriver , o.nom_de_pays , o.prix);
    		}else{s--;}
	}
	fclose(f);
	fclose(f1);
	remove("offre.txt");
	rename("recherche.txt","offre.txt");
}
		

void modifier_offre(offre d ,int id)
{
	int s=0;
	offre o;
	FILE*f;
  FILE*f1;
  f=fopen("offre.txt","r");
	f1=fopen("recherche.txt","w");

  while(fscanf(f,"%d %s %s %s %s\n",&o.id, o.date_de_depart ,o.date_arriver , o.nom_de_pays , o.prix)!=EOF)
  { s++;
    		if(id != o.id)
    		{ 
		o.id=s;
		fprintf(f1,"%d %s %s %s %s\n",o.id,
o.date_de_depart ,o.date_arriver , o.nom_de_pays , o.prix);
    		}else{
fprintf(f1,"%d %s %s %s %s\n",o.id,
d.date_de_depart ,d.date_arriver , d.nom_de_pays , d.prix);
}
	}
	fclose(f);
	fclose(f1);
	remove("offre.txt");
	rename("recherche.txt","offre.txt");
}
		
int verif_offre(int id)
{
	offre d;
	FILE*f;
	f=fopen("offre.txt","r");
	if(f!=NULL)
	{
		while(fscanf(f,"%d %s %s %s %s\n",&d.id, d.date_de_depart ,d.date_arriver , d.nom_de_pays , d.prix)!=EOF)
		{
      if (d.id == id)
			{
				return 1;
			}
		}
		return 0;
	fclose(f);
	}
}
