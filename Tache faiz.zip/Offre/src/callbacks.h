#include <gtk/gtk.h>


void
on_buttonajouter_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonAjouter2_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonRetour1_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonmodifier_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_buttonRechercher_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_buttonModifier2_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonRetour2_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_buttonAfficher_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonRetour3_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_buttonRechercher2_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonRetour4_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_buttonSupprimer2_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_buttonSupprimer_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);
